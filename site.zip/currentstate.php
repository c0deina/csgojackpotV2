<?php
@include_once ("set.php");
echo fetchinfo("value","info","name","state");
?>